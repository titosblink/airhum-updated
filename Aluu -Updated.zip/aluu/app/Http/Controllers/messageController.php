<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Http\Helpers\Ebulksms;

class messageController extends Controller
{
    public function MsgSend(Request $request){

			$data=$request->all();
	        
	        $username = 'aoclems@gmail.com';
		    $sendername = $data['sendername'];
		    $recipients = $data['pnum'];
		    $message = $data['msg'];
		    

		    // $smspage = 'http://justsms.com.ng/index.php?option=com_spc&comm=spc_api&username=titoranky&password=titoman&sender=@@$sendername@@&recipient=@@$recipients@@&message=@@$message@@&';
 
 			$smspage = 'https://smsexperience.com/api/sms/dnd-route?username='.$username.'&password=A123tito12&sender='
 			.'@@'.$sendername.'@@&recipient=@@'.$recipients.'@@&message=@@'.$message.'@@';

		    return redirect()->to($smspage);
		    //return redirect()->to('/');
		 	

		}
	}
	

	https://smsexperience.com/api/sms/sendsms?username=xxx&password=xxx&sender=@@sender@@&recipient=@@recipient@@&message=@@message@@