<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class administrator extends Model
{
    protected $table = "administrator";
}
