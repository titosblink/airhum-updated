<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="container-fluid py-4">

    <h1>LIST OF CUSTOMERS/PHONE NUMBER</h1>
      <ol type = "1">
         <a href="#"><li>Pearl - 09058458189</li></a>
         <a href="#"><li>Nnenna - 08066526235</li></a>
         <a href="#"><li>Clement - 08068180350</li></a>
      </ol>

      <div class="card-body">
              <form role="form text-left" method="post" action="sendmsg" id="sendmsg">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <input type="text" class="form-control" placeholder="Sender Name" aria-label="Sender Name" aria-describedby="email-addon" id="sendername" name="sendername">
                </div>
                <div class="mb-3">
                  <input type="text" class="form-control" placeholder="Phone Number" aria-label="Phone Number" aria-describedby="email-addon" id="pnum" name="pnum">
                </div>
                <div class="mb-3">
                  <textarea class="form-control" placeholder="Message" id="msg" name="msg"></textarea> 
                </div>
                <div class="text-center">
                  <button type="submit" class="btn bg-gradient-dark w-100 my-4 mb-2">Send Message</button>
                </div>
                
              </form> 
            </div>


      
  </div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\aluu\resources\views/dashboard.blade.php ENDPATH**/ ?>